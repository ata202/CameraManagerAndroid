\
package com.example.cameramanager

import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.MediaItem
import com.google.android.exoplayer2.source.rtsp.RtspMediaSource
import com.example.cameramanager.databinding.ActivityRtspBinding

class RtspPlayerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRtspBinding
    private var player: ExoPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRtspBinding.inflate(layoutInflater)
        setContentView(binding.root)
        title = intent.getStringExtra("rtsp") ?: "RTSP Player"
    }

    override fun onStart() {
        super.onStart()
        val url = intent.getStringExtra("rtsp") ?: return
        player = ExoPlayer.Builder(this).build()
        binding.playerView.player = player
        val mediaItem = MediaItem.fromUri(Uri.parse(url))
        val mediaSource = RtspMediaSource.Factory().createMediaSource(mediaItem)
        player?.setMediaSource(mediaSource)
        player?.prepare()
        player?.playWhenReady = true
    }

    override fun onStop() {
        super.onStop()
        player?.release()
        player = null
    }
}
