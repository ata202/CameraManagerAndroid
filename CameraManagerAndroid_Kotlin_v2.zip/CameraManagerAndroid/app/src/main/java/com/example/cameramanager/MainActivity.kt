\
package com.example.cameramanager

import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.cameramanager.databinding.ActivityMainBinding
import kotlinx.coroutines.*
import java.net.InetAddress
import java.net.Socket
import java.net.NetworkInterface

data class DeviceItem(val ip: String, val openPorts: List<Int>) {
    val protocols: String
        get() {
            val set = mutableSetOf<String>()
            if (openPorts.contains(554)) set.add("RTSP")
            if (openPorts.contains(80)) set.add("HTTP")
            return if (set.isEmpty()) "—" else set.joinToString(", ")
        }
}

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val items = mutableListOf<DeviceItem>()
    private lateinit var adapter: DeviceAdapter
    private val portsToCheck = listOf(80, 554)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter = DeviceAdapter(items) { item ->
            val input = EditText(this)
            input.hint = "rtsp://user:pass@${item.ip}:554/"
            AlertDialog.Builder(this)
                .setTitle("رابط RTSP")
                .setMessage("أدخل رابط RTSP أو اترك الافتراضي مع تعديل بيانات الدخول")
                .setView(input)
                .setPositiveButton("تشغيل") { _, _ ->
                    val url = (input.text?.toString()?.takeIf { it.isNotBlank() }
                        ?: "rtsp://user:pass@${item.ip}:554/")
                    val i = Intent(this, RtspPlayerActivity::class.java)
                    i.putExtra("rtsp", url)
                    startActivity(i)
                }
                .setNegativeButton("إلغاء", null)
                .show()
        }
        binding.recycler.layoutManager = LinearLayoutManager(this)
        binding.recycler.adapter = adapter

        binding.btnScan.setOnClickListener { doScan() }
        binding.btnAdd.setOnClickListener { addManual() }
    }

    private fun addManual() {
        val input = EditText(this)
        input.hint = "rtsp://user:pass@192.168.1.10:554/"
        AlertDialog.Builder(this)
            .setTitle("إضافة RTSP")
            .setView(input)
            .setPositiveButton("تشغيل") { _, _ ->
                val url = input.text?.toString()
                if (!url.isNullOrBlank()) {
                    val i = Intent(this, RtspPlayerActivity::class.java)
                    i.putExtra("rtsp", url)
                    startActivity(i)
                } else {
                    Toast.makeText(this, "أدخل رابطاً صحيحاً", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun doScan() {
        items.clear()
        adapter.notifyDataSetChanged()
        Toast.makeText(this, "بدء الفحص...", Toast.LENGTH_SHORT).show()

        CoroutineScope(Dispatchers.IO).launch {
            val subnet = getLocalSubnet24()
            if (subnet == null) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@MainActivity, "تعذر تحديد الشبكة المحلية", Toast.LENGTH_LONG).show()
                }
                return@launch
            }
            val hosts = (1..254).map { "$subnet.$it" }
            val results = mutableListOf<DeviceItem>()
            val jobs = hosts.map { ip ->
                async {
                    if (isReachable(ip)) {
                        val open = portsToCheck.filter { isPortOpen(ip, it, 250) }
                        if (open.isNotEmpty()) DeviceItem(ip, open) else null
                    } else null
                }
            }
            jobs.awaitAll().filterNotNull().forEach { results.add(it) }
            withContext(Dispatchers.Main) {
                items.addAll(results.sortedBy { it.ip })
                adapter.notifyDataSetChanged()
                Toast.makeText(this@MainActivity, "انتهى الفحص: ${items.size} جهاز", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun getLocalSubnet24(): String? {
        val ifaces = NetworkInterface.getNetworkInterfaces() ?: return null
        for (iface in ifaces) {
            val addrs = iface.inetAddresses
            while (addrs.hasMoreElements()) {
                val addr = addrs.nextElement()
                if (!addr.isLoopbackAddress && addr.hostAddress.indexOf(":") == -1) {
                    val parts = addr.hostAddress.split(".")
                    if (parts.size == 4) {
                        return parts.take(3).joinToString(".") // /24 guess
                    }
                }
            }
        }
        return null
    }

    private fun isReachable(ip: String): Boolean {
        return try {
            InetAddress.getByName(ip).isReachable(200)
        } catch (e: Exception) {
            false
        }
    }

    private fun isPortOpen(ip: String, port: Int, timeoutMs: Int): Boolean {
        return try {
            Socket(ip, port).use { true }
        } catch (e: Exception) {
            false
        }
    }
}
