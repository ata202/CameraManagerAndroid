// Project root (no extra config needed here)
