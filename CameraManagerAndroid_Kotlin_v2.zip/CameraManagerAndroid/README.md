# CameraManagerAndroid (Kotlin)

تطبيق أندرويد بسيط لفحص شبكة /24 محليًا (TCP 80/554) وعرض أجهزة محتملة لكاميرات IP،
مع مشغل RTSP يعتمد على **ExoPlayer (extension-rtsp)**.

## البناء إلى APK عبر GitHub Actions
- ارفع هذا الملف ZIP إلى مستودعك.
- أنشئ Workflow كما شرحتُ لك سابقًا وسيفك الضغط ويبني APK.

بعد البناء، حمّل **app-debug-apk** من تبويب **Actions → Artifacts**.
